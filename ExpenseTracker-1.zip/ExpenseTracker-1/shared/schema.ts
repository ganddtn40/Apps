import { pgTable, text, serial, integer, boolean, doublePrecision, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Categories for expenses and budgets
export const expenseCategories = [
  "Food & Dining",
  "Transportation",
  "Entertainment",
  "Utilities",
  "Housing",
  "Health & Medical",
  "Education",
  "Shopping",
  "Personal",
  "Investments",
  "Other"
] as const;

// Categories specifically for bills
export const billCategories = [
  "Electricity",
  "Water",
  "Internet",
  "Phone",
  "Rent",
  "Insurance",
  "Loan Payment",
  "Subscription",
  "Other"
] as const;

// Payment methods
export const paymentMethods = [
  "Cash",
  "Debit Card",
  "Credit Card",
  "Bank Transfer",
  "E-Wallet",
  "Other"
] as const;

// Recurrence periods
export const recurrencePeriods = [
  "Monthly",
  "Weekly",
  "Yearly",
  "One-time"
] as const;

// Expense table
export const expenses = pgTable("expenses", {
  id: serial("id").primaryKey(),
  description: text("description").notNull(),
  amount: doublePrecision("amount").notNull(),
  category: text("category").notNull(),
  date: timestamp("date").notNull(),
  paymentMethod: text("payment_method").notNull(),
  notes: text("notes"),
});

// Budget table
export const budgets = pgTable("budgets", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  amount: doublePrecision("amount").notNull(),
  period: text("period").notNull(),
  startDate: timestamp("start_date").notNull(),
  alertPercentage: integer("alert_percentage").notNull(),
  currentSpent: doublePrecision("current_spent").default(0).notNull(),
});

// Bill table
export const bills = pgTable("bills", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  amount: doublePrecision("amount").notNull(),
  category: text("category").notNull(),
  dueDate: timestamp("due_date").notNull(),
  recurrence: text("recurrence").notNull(),
  reminderDays: integer("reminder_days").notNull(),
  notes: text("notes"),
  isPaid: boolean("is_paid").default(false).notNull(),
});

// Define Zod schemas using drizzle-zod
export const insertExpenseSchema = createInsertSchema(expenses).omit({ id: true });
export const insertBudgetSchema = createInsertSchema(budgets).omit({ id: true, currentSpent: true });
export const insertBillSchema = createInsertSchema(bills).omit({ id: true });

// Custom schemas with validations
export const expenseSchema = insertExpenseSchema.extend({
  category: z.enum(expenseCategories),
  paymentMethod: z.enum(paymentMethods),
  amount: z.number().positive().min(0.01),
});

export const budgetSchema = insertBudgetSchema.extend({
  category: z.enum(expenseCategories),
  period: z.enum(recurrencePeriods),
  amount: z.number().positive().min(0.01),
  alertPercentage: z.number().int().min(1).max(100),
});

export const billSchema = insertBillSchema.extend({
  category: z.enum(billCategories),
  recurrence: z.enum(recurrencePeriods),
  amount: z.number().positive().min(0.01),
  reminderDays: z.number().int().min(0).max(30),
});

// Define types
export type Expense = typeof expenses.$inferSelect;
export type InsertExpense = z.infer<typeof expenseSchema>;
export type Budget = typeof budgets.$inferSelect;
export type InsertBudget = z.infer<typeof budgetSchema>;
export type Bill = typeof bills.$inferSelect;
export type InsertBill = z.infer<typeof billSchema>;
export type ExpenseCategory = typeof expenseCategories[number];
export type BillCategory = typeof billCategories[number];
export type PaymentMethod = typeof paymentMethods[number];
export type RecurrencePeriod = typeof recurrencePeriods[number];
