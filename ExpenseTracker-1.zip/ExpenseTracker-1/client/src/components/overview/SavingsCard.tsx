import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Landmark, TrendingUp } from "lucide-react";
import { formatRupiah, formatPercentage } from "@/utils/formatters";
import { Progress } from "@/components/ui/progress";

interface SavingsCardProps {
  targetAmount: number;
  currentAmount: number;
  percentReached: number;
  isLoading?: boolean;
}

const SavingsCard: React.FC<SavingsCardProps> = ({ 
  targetAmount, 
  currentAmount, 
  percentReached,
  isLoading = false
}) => {
  if (isLoading) {
    return (
      <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-sm font-medium text-gray-500">Savings Target</p>
              <div className="h-7 w-28 bg-gray-200 animate-pulse rounded mt-1"></div>
              <div className="h-4 w-20 bg-gray-200 animate-pulse rounded mt-2"></div>
            </div>
            <div className="w-12 h-12 rounded-full bg-gray-200 animate-pulse"></div>
          </div>
          <div className="mt-4">
            <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
              <div className="h-3 w-16 bg-gray-200 animate-pulse rounded"></div>
              <div className="h-3 w-24 bg-gray-200 animate-pulse rounded"></div>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div className="bg-gray-300 h-2 rounded-full" style={{ width: "20%" }}></div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-500">Savings Target</p>
            <h2 className="text-2xl font-bold mt-1">{formatRupiah(targetAmount)}</h2>
            <p className="text-sm text-success flex items-center mt-1">
              <TrendingUp className="mr-1 h-4 w-4" />
              <span>{formatPercentage(percentReached)} reached</span>
            </p>
          </div>
          <div className="w-12 h-12 rounded-full bg-success bg-opacity-10 flex items-center justify-center">
            <Landmark className="text-success h-6 w-6" />
          </div>
        </div>
        <div className="mt-4">
          <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
            <span>{formatRupiah(currentAmount)}</span>
            <span>{formatRupiah(targetAmount)}</span>
          </div>
          <Progress value={percentReached} className="h-2 bg-gray-200" indicatorClassName="bg-success" />
        </div>
      </CardContent>
    </Card>
  );
};

export default SavingsCard;
