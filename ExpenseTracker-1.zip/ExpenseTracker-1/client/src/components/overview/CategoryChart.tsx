import React, { useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { formatRupiah, formatPercentage } from "@/utils/formatters";

interface CategoryData {
  name: string;
  value: number;
  color: string;
}

interface CategoryChartProps {
  data: CategoryData[];
  total: number;
  isLoading?: boolean;
  onPeriodChange?: (period: string) => void;
}

const COLORS = ['#2563eb', '#4ade80', '#facc15', '#f43f5e', '#94a3b8'];

const CategoryChart: React.FC<CategoryChartProps> = ({
  data,
  total,
  isLoading = false,
  onPeriodChange
}) => {
  if (isLoading) {
    return (
      <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold text-gray-800">Expense Categories</CardTitle>
            <Skeleton className="h-9 w-36" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-48 flex items-center justify-center">
            <Skeleton className="h-36 w-36 rounded-full" />
          </div>
          <div className="space-y-2 mt-4">
            {[...Array(5)].map((_, index) => (
              <div key={index} className="flex items-center text-sm">
                <Skeleton className="w-3 h-3 rounded-full mr-2" />
                <Skeleton className="h-4 w-32 flex-1" />
                <Skeleton className="h-4 w-12" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-gray-800">Expense Categories</CardTitle>
          <Select defaultValue="thisMonth" onValueChange={onPeriodChange}>
            <SelectTrigger className="text-sm border-gray-300 h-9 w-36">
              <SelectValue placeholder="Select period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="thisMonth">This Month</SelectItem>
              <SelectItem value="lastMonth">Last Month</SelectItem>
              <SelectItem value="thisYear">This Year</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-48 mb-4">
          {data.length === 0 ? (
            <div className="h-full flex items-center justify-center">
              <p className="text-gray-500 text-sm">No data available</p>
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data}
                  cx="50%"
                  cy="50%"
                  innerRadius="60%"
                  outerRadius="80%"
                  paddingAngle={5}
                  dataKey="value"
                >
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color || COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value) => formatRupiah(Number(value))}
                  labelStyle={{ color: "#333" }}
                />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>
        <div className="space-y-2 mt-4">
          {data.map((item, index) => {
            const percentage = total > 0 ? (item.value / total) * 100 : 0;
            
            return (
              <div key={index} className="flex items-center text-sm">
                <span className={`w-3 h-3 rounded-full mr-2`} style={{ backgroundColor: item.color || COLORS[index % COLORS.length] }}></span>
                <span className="text-gray-600 flex-1">{item.name}</span>
                <span className="font-medium">{formatPercentage(percentage)}</span>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};

export default CategoryChart;
