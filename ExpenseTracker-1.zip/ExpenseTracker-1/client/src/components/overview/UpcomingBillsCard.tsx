import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Calendar, Receipt } from "lucide-react";
import { formatRupiah } from "@/utils/formatters";

interface UpcomingBillsCardProps {
  totalAmount: number;
  count: number;
  daysUntilNext: number;
  isLoading?: boolean;
}

const UpcomingBillsCard: React.FC<UpcomingBillsCardProps> = ({ 
  totalAmount, 
  count, 
  daysUntilNext,
  isLoading = false
}) => {
  if (isLoading) {
    return (
      <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-500">Upcoming Bills</p>
              <div className="h-7 w-28 bg-gray-200 animate-pulse rounded mt-1"></div>
              <div className="h-4 w-32 bg-gray-200 animate-pulse rounded mt-2"></div>
            </div>
            <div className="w-12 h-12 rounded-full bg-gray-200 animate-pulse"></div>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-500">Upcoming Bills</p>
            <h2 className="text-2xl font-bold mt-1">{formatRupiah(totalAmount)}</h2>
            <p className="text-sm text-warning flex items-center mt-1">
              <Calendar className="mr-1 h-4 w-4" />
              <span>{count} bills in {daysUntilNext} days</span>
            </p>
          </div>
          <div className="w-12 h-12 rounded-full bg-danger bg-opacity-10 flex items-center justify-center">
            <Receipt className="text-danger h-6 w-6" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default UpcomingBillsCard;
