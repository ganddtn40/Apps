import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Wallet, TrendingDown } from "lucide-react";
import { formatRupiah, formatPercentage } from "@/utils/formatters";
import { Progress } from "@/components/ui/progress";

interface BudgetStatusCardProps {
  totalAmount: number;
  remainingAmount: number;
  percentUsed: number;
  isLoading?: boolean;
}

const BudgetStatusCard: React.FC<BudgetStatusCardProps> = ({ 
  totalAmount, 
  remainingAmount, 
  percentUsed,
  isLoading = false
}) => {
  if (isLoading) {
    return (
      <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-sm font-medium text-gray-500">Budget Status</p>
              <div className="h-7 w-28 bg-gray-200 animate-pulse rounded mt-1"></div>
              <div className="h-4 w-32 bg-gray-200 animate-pulse rounded mt-2"></div>
            </div>
            <div className="w-12 h-12 rounded-full bg-gray-200 animate-pulse"></div>
          </div>
          <div className="mt-4">
            <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
              <div className="h-3 w-16 bg-gray-200 animate-pulse rounded"></div>
              <div className="h-3 w-24 bg-gray-200 animate-pulse rounded"></div>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div className="bg-gray-300 h-2 rounded-full" style={{ width: "40%" }}></div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  // Determine color based on percentage used
  const progressColor = percentUsed > 80 ? "bg-warning" : "bg-success";
  
  return (
    <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-500">Budget Status</p>
            <h2 className="text-2xl font-bold mt-1">{formatRupiah(remainingAmount)}</h2>
            <p className="text-sm text-success flex items-center mt-1">
              <TrendingDown className="mr-1 h-4 w-4" />
              <span>Remaining from budget</span>
            </p>
          </div>
          <div className="w-12 h-12 rounded-full bg-warning bg-opacity-10 flex items-center justify-center">
            <Wallet className="text-warning h-6 w-6" />
          </div>
        </div>
        <div className="mt-4">
          <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
            <span>{formatPercentage(percentUsed)} used</span>
            <span>{formatRupiah(totalAmount)}</span>
          </div>
          <Progress value={percentUsed} className="h-2 bg-gray-200" indicatorClassName={progressColor} />
        </div>
      </CardContent>
    </Card>
  );
};

export default BudgetStatusCard;
