import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Banknote, Calendar, ShoppingBag, Droplet, Utensils, Film, Wifi } from "lucide-react";
import { formatRupiah, getRelativeTime } from "@/utils/formatters";
import { Skeleton } from "@/components/ui/skeleton";
import IconBadge from "@/components/ui/IconBadge";
import { Expense } from "@shared/schema";

interface RecentTransactionsProps {
  transactions: Expense[];
  isLoading?: boolean;
}

const iconMap = {
  "Food & Dining": { icon: Utensils, bgColor: "bg-blue-100", textColor: "text-primary" },
  "Transportation": { icon: Droplet, bgColor: "bg-green-100", textColor: "text-success" },
  "Entertainment": { icon: Film, bgColor: "bg-red-100", textColor: "text-danger" },
  "Utilities": { icon: Wifi, bgColor: "bg-purple-100", textColor: "text-purple-600" },
  "Shopping": { icon: ShoppingBag, bgColor: "bg-yellow-100", textColor: "text-warning" },
  "Other": { icon: Banknote, bgColor: "bg-gray-100", textColor: "text-gray-600" }
};

const RecentTransactions: React.FC<RecentTransactionsProps> = ({ transactions, isLoading = false }) => {
  if (isLoading) {
    return (
      <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold text-gray-800">Recent Transactions</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(5)].map((_, index) => (
              <div key={index} className="flex items-center justify-between py-3 border-b border-gray-100">
                <div className="flex items-center">
                  <Skeleton className="w-10 h-10 rounded-full mr-3" />
                  <div>
                    <Skeleton className="h-5 w-32" />
                    <Skeleton className="h-4 w-20 mt-1" />
                  </div>
                </div>
                <div className="text-right">
                  <Skeleton className="h-5 w-24 ml-auto" />
                  <Skeleton className="h-4 w-16 ml-auto mt-1" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-gray-800">Recent Transactions</CardTitle>
          <a href="/expenses" className="text-primary text-sm font-medium">View All</a>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {transactions.length === 0 ? (
            <div className="py-8 text-center">
              <p className="text-gray-500">No transactions yet</p>
            </div>
          ) : (
            transactions.map((transaction) => {
              const { icon: Icon, bgColor, textColor } = 
                iconMap[transaction.category as keyof typeof iconMap] || 
                iconMap.Other;
              
              return (
                <div key={transaction.id} className="flex items-center justify-between py-3 border-b border-gray-100">
                  <div className="flex items-center">
                    <IconBadge 
                      icon={Icon} 
                      bgColor={bgColor} 
                      textColor={textColor} 
                      className="mr-3" 
                    />
                    <div>
                      <p className="font-medium text-gray-800">{transaction.description}</p>
                      <p className="text-sm text-gray-500">{transaction.category}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-gray-800">{formatRupiah(transaction.amount)}</p>
                    <p className="text-xs text-gray-500">{getRelativeTime(transaction.date)}</p>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default RecentTransactions;
