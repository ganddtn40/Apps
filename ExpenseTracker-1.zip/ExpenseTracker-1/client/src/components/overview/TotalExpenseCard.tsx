import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Banknote, TrendingUp, TrendingDown } from "lucide-react";
import { formatRupiah } from "@/utils/formatters";

interface TotalExpenseCardProps {
  amount: number;
  percentChange: number;
  isLoading?: boolean;
}

const TotalExpenseCard: React.FC<TotalExpenseCardProps> = ({ 
  amount, 
  percentChange,
  isLoading = false
}) => {
  const isIncreasing = percentChange >= 0;
  
  if (isLoading) {
    return (
      <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-500">Total Expenses</p>
              <div className="h-7 w-28 bg-gray-200 animate-pulse rounded mt-1"></div>
              <div className="h-4 w-24 bg-gray-200 animate-pulse rounded mt-2"></div>
            </div>
            <div className="w-12 h-12 rounded-full bg-gray-200 animate-pulse"></div>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-500">Total Expenses</p>
            <h2 className="text-2xl font-bold mt-1">{formatRupiah(amount)}</h2>
            <p className={`text-sm flex items-center mt-1 ${isIncreasing ? 'text-danger' : 'text-success'}`}>
              {isIncreasing ? (
                <TrendingUp className="mr-1 h-4 w-4" />
              ) : (
                <TrendingDown className="mr-1 h-4 w-4" />
              )}
              <span>{Math.abs(percentChange).toFixed(1)}% from last month</span>
            </p>
          </div>
          <div className="w-12 h-12 rounded-full bg-primary bg-opacity-10 flex items-center justify-center">
            <Banknote className="text-primary h-6 w-6" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default TotalExpenseCard;
