import React from "react";
import { getCategoryColorClasses } from "@/utils/formatters";

interface CategoryBadgeProps {
  category: string;
  className?: string;
}

const CategoryBadge: React.FC<CategoryBadgeProps> = ({ category, className = "" }) => {
  const { bg, text } = getCategoryColorClasses(category);
  
  return (
    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${bg} ${text} ${className}`}>
      {category}
    </span>
  );
};

export default CategoryBadge;
