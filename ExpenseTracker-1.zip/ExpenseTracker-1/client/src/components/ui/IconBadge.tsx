import React from "react";
import { LucideIcon } from "lucide-react";

interface IconBadgeProps {
  icon: LucideIcon;
  bgColor?: string;
  textColor?: string;
  className?: string;
}

const IconBadge: React.FC<IconBadgeProps> = ({ 
  icon: Icon,
  bgColor = "bg-blue-100",
  textColor = "text-primary",
  className = ""
}) => {
  return (
    <div className={`w-10 h-10 rounded-full ${bgColor} flex items-center justify-center ${textColor} ${className}`}>
      <Icon className="h-5 w-5" />
    </div>
  );
};

export default IconBadge;
