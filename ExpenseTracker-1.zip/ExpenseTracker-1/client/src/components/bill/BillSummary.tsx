import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { formatRupiah, formatDate } from "@/utils/formatters";
import { Bill } from "@shared/schema";
import { Receipt, Building, Calendar } from "lucide-react";

interface BillSummaryProps {
  bills: Bill[];
  isLoading: boolean;
}

const BillSummary: React.FC<BillSummaryProps> = ({ bills, isLoading }) => {
  // Calculate totals
  const totalBills = bills.reduce((sum, bill) => sum + bill.amount, 0);
  const unpaidBills = bills.filter(bill => !bill.isPaid);
  const paidBills = bills.filter(bill => bill.isPaid);
  const totalUnpaid = unpaidBills.reduce((sum, bill) => sum + bill.amount, 0);
  const totalPaid = paidBills.reduce((sum, bill) => sum + bill.amount, 0);

  // Get recent payment history (last 5 paid bills)
  const recentPayments = paidBills
    .sort((a, b) => new Date(b.dueDate).getTime() - new Date(a.dueDate).getTime())
    .slice(0, 5);

  if (isLoading) {
    return (
      <>
        <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-semibold text-gray-800">This Month's Bills</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-6 w-28" />
              </div>
              
              <div className="border-t border-gray-200 pt-4">
                <Skeleton className="h-4 w-32 mb-3" />
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-semibold text-gray-800">Payment History</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[...Array(3)].map((_, index) => (
                <div key={index} className="flex items-center justify-between py-2 border-b border-gray-100">
                  <div>
                    <Skeleton className="h-4 w-32 mb-1" />
                    <Skeleton className="h-3 w-20" />
                  </div>
                  <div className="text-right">
                    <Skeleton className="h-4 w-20 mb-1" />
                    <Skeleton className="h-3 w-12 ml-auto" />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </>
    );
  }

  return (
    <>
      <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-semibold text-gray-800">This Month's Bills</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Total Bills</span>
              <span className="text-lg font-bold text-gray-800">{formatRupiah(totalBills)}</span>
            </div>
            
            <div className="border-t border-gray-200 pt-4">
              <div className="text-sm font-medium text-gray-600 mb-3">Bill Status</div>
              <div className="flex items-center justify-between text-sm mb-2">
                <span className="text-gray-600">Unpaid</span>
                <span className="text-danger font-medium">{formatRupiah(totalUnpaid)}</span>
              </div>
              <div className="flex items-center justify-between text-sm mb-2">
                <span className="text-gray-600">Paid</span>
                <span className="text-success font-medium">{formatRupiah(totalPaid)}</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-semibold text-gray-800">Payment History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentPayments.length === 0 ? (
              <div className="text-center py-4 text-gray-500">
                No payment history yet
              </div>
            ) : (
              recentPayments.map((bill) => (
                <div key={bill.id} className="flex items-center justify-between py-2 border-b border-gray-100">
                  <div>
                    <p className="font-medium text-gray-800">{bill.name}</p>
                    <p className="text-xs text-gray-500">
                      <span className="inline-flex items-center">
                        <Calendar className="h-3 w-3 mr-1" />
                        {formatDate(bill.dueDate)}
                      </span>
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-gray-800">{formatRupiah(bill.amount)}</p>
                    <p className="text-xs text-success">Paid</p>
                  </div>
                </div>
              ))
            )}
            
            {recentPayments.length > 0 && (
              <div className="pt-2">
                <a href="#" className="text-primary text-sm font-medium">View all payment history</a>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </>
  );
};

export default BillSummary;
