import React, { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { formatRupiah, getDaysUntilText } from "@/utils/formatters";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import IconBadge from "@/components/ui/IconBadge";
import {
  Receipt,
  HomeIcon,
  Wifi,
  Droplet,
  Lightbulb,
  CreditCard,
  Building,
  MoreHorizontal,
  Check,
  X,
  Pencil,
  Trash
} from "lucide-react";
import { Bill } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useMutation, useQueryClient } from "@tanstack/react-query";

interface BillListProps {
  bills: Bill[];
  isLoading: boolean;
  onEditBill: (bill: Bill) => void;
}

const iconMap = {
  "Electricity": { icon: Lightbulb, bgColor: "bg-yellow-100", textColor: "text-yellow-800" },
  "Water": { icon: Droplet, bgColor: "bg-blue-100", textColor: "text-blue-800" },
  "Internet": { icon: Wifi, bgColor: "bg-purple-100", textColor: "text-purple-800" },
  "Phone": { icon: Receipt, bgColor: "bg-green-100", textColor: "text-green-800" },
  "Rent": { icon: HomeIcon, bgColor: "bg-indigo-100", textColor: "text-indigo-800" },
  "Insurance": { icon: Building, bgColor: "bg-gray-100", textColor: "text-gray-800" },
  "Loan Payment": { icon: CreditCard, bgColor: "bg-red-100", textColor: "text-red-800" }
};

const BillList: React.FC<BillListProps> = ({ 
  bills, 
  isLoading,
  onEditBill
}) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedBill, setSelectedBill] = useState<Bill | null>(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/bills/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bills'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/summary'] });
      toast({
        title: "Bill deleted",
        description: "The bill has been deleted successfully.",
        variant: "default"
      });
      setShowDeleteDialog(false);
    },
    onError: (error) => {
      toast({
        title: "Failed to delete bill",
        description: (error as Error).message || "An error occurred while deleting the bill.",
        variant: "destructive"
      });
    }
  });

  const togglePaidMutation = useMutation({
    mutationFn: async ({ id, isPaid }: { id: number; isPaid: boolean }) => {
      await apiRequest('PATCH', `/api/bills/${id}/pay`, { isPaid });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bills'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/summary'] });
      toast({
        title: "Bill status updated",
        description: "The bill payment status has been updated.",
        variant: "default"
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update bill status",
        description: (error as Error).message || "An error occurred while updating the bill status.",
        variant: "destructive"
      });
    }
  });

  const handleDeleteClick = (bill: Bill) => {
    setSelectedBill(bill);
    setShowDeleteDialog(true);
  };

  const confirmDelete = () => {
    if (selectedBill) {
      deleteMutation.mutate(selectedBill.id);
    }
  };

  const handleTogglePaid = (bill: Bill, isPaid: boolean) => {
    togglePaidMutation.mutate({ id: bill.id, isPaid });
  };

  // Sort bills by due date (closest first)
  const sortedBills = [...bills].sort((a, b) => 
    new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
  );

  return (
    <Card className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      <CardHeader className="pb-2 px-6 pt-6">
        <CardTitle className="text-lg font-semibold text-gray-800">Upcoming Bills</CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="divide-y divide-gray-200">
          {isLoading ? (
            [...Array(3)].map((_, index) => (
              <div key={index} className="p-6">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center">
                      <Skeleton className="w-10 h-10 rounded-full mr-3" />
                      <div>
                        <Skeleton className="h-5 w-32 mb-1" />
                        <Skeleton className="h-4 w-40" />
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between lg:justify-end w-full lg:w-auto gap-4">
                    <Skeleton className="h-6 w-24" />
                    <div className="flex items-center space-x-2">
                      <Skeleton className="h-9 w-16" />
                      <Skeleton className="h-9 w-9" />
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : sortedBills.length === 0 ? (
            <div className="p-6 text-center text-gray-500">
              No bills found. Add a bill to get started.
            </div>
          ) : (
            sortedBills.map((bill) => {
              const { icon: Icon, bgColor, textColor } = 
                iconMap[bill.category as keyof typeof iconMap] || 
                { icon: Receipt, bgColor: "bg-gray-100", textColor: "text-gray-800" };
              
              const daysUntilText = getDaysUntilText(bill.dueDate);
              const isPastDue = new Date(bill.dueDate) < new Date() && !bill.isPaid;
              
              let statusTextColor = "text-gray-500";
              if (isPastDue) {
                statusTextColor = "text-danger";
              } else if (daysUntilText.includes("today") || daysUntilText.includes("tomorrow")) {
                statusTextColor = "text-warning";
              }
              
              return (
                <div key={bill.id} className="p-6">
                  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center">
                        <IconBadge
                          icon={Icon}
                          bgColor={bgColor}
                          textColor={textColor}
                          className="mr-3"
                        />
                        <div>
                          <h4 className="text-lg font-medium text-gray-800">{bill.name}</h4>
                          <div className="flex items-center text-sm text-gray-500 mt-1">
                            <span className="flex items-center">
                              <Building className="mr-1 h-4 w-4" />
                              {bill.category}
                            </span>
                            <span className="mx-2">•</span>
                            <span className={`flex items-center ${statusTextColor} font-medium`}>
                              {bill.isPaid ? "Paid" : daysUntilText}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between lg:justify-end w-full lg:w-auto gap-4">
                      <div className="text-xl font-bold text-gray-800">
                        {formatRupiah(bill.amount)}
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant={bill.isPaid ? "outline" : "default"}
                          size="sm"
                          className={bill.isPaid ? "" : "bg-success hover:bg-success/90"}
                          onClick={() => handleTogglePaid(bill, !bill.isPaid)}
                          disabled={togglePaidMutation.isPending}
                        >
                          {bill.isPaid ? (
                            <>
                              <X className="mr-1 h-4 w-4" />
                              <span>Unpaid</span>
                            </>
                          ) : (
                            <>
                              <Check className="mr-1 h-4 w-4" />
                              <span>Pay</span>
                            </>
                          )}
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="outline" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => onEditBill(bill)}>
                              <Pencil className="mr-2 h-4 w-4" />
                              <span>Edit</span>
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              onClick={() => handleDeleteClick(bill)}
                              className="text-red-600"
                            >
                              <Trash className="mr-2 h-4 w-4" />
                              <span>Delete</span>
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </CardContent>

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Bill</DialogTitle>
          </DialogHeader>
          <p className="py-4">
            Are you sure you want to delete this bill? This action cannot be undone.
          </p>
          {selectedBill && (
            <div className="my-2 p-4 bg-gray-50 rounded-md">
              <p><strong>Name:</strong> {selectedBill.name}</p>
              <p><strong>Amount:</strong> {formatRupiah(selectedBill.amount)}</p>
              <p><strong>Category:</strong> {selectedBill.category}</p>
            </div>
          )}
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Cancel</Button>
            </DialogClose>
            <Button 
              variant="destructive" 
              onClick={confirmDelete}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
};

export default BillList;
