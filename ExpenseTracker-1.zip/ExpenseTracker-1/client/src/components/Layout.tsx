import React, { useState, useEffect } from "react";
import Sidebar from "./Sidebar";
import { useLocation } from "wouter";
import {
  Menu,
  Wallet,
  PieChart,
  Banknote,
  Receipt
} from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { useMediaQuery } from "@/hooks/use-mobile"; 

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [location] = useLocation();
  const isMobile = useMediaQuery("(max-width: 1024px)");
  const [open, setOpen] = useState(false);
  
  // Get page title based on current location
  const getPageTitle = () => {
    switch (location) {
      case "/":
        return "Dashboard";
      case "/expenses":
        return "Expenses";
      case "/budgets":
        return "Budgets";
      case "/bills":
        return "Bills";
      default:
        return "Budget Tracker";
    }
  };

  // Close mobile menu when clicking on a link or when resizing to desktop
  useEffect(() => {
    setOpen(false);
  }, [location, isMobile]);

  const sidebarItems = [
    {
      label: "Dashboard",
      icon: <PieChart size={20} />,
      href: "/",
      active: location === "/"
    },
    {
      label: "Expenses",
      icon: <Banknote size={20} />,
      href: "/expenses",
      active: location === "/expenses"
    },
    {
      label: "Budgets",
      icon: <Wallet size={20} />,
      href: "/budgets",
      active: location === "/budgets"
    },
    {
      label: "Bills",
      icon: <Receipt size={20} />,
      href: "/bills",
      active: location === "/bills"
    }
  ];

  return (
    <div className="flex flex-col min-h-screen">
      {/* Mobile header */}
      {isMobile && (
        <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
          <div className="flex items-center justify-between px-4 py-3">
            <div className="flex items-center">
              <Wallet className="text-primary mr-2 h-6 w-6" />
              <h1 className="text-xl font-bold text-gray-800">BudgetTracker</h1>
            </div>
            <Sheet open={open} onOpenChange={setOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Menu className="h-6 w-6" />
                  <span className="sr-only">Toggle menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="p-0 w-64">
                <Sidebar items={sidebarItems} />
              </SheetContent>
            </Sheet>
          </div>
        </header>
      )}

      <div className="flex flex-1">
        {/* Desktop sidebar */}
        {!isMobile && (
          <aside className="w-64 bg-white border-r border-gray-200 fixed h-screen">
            <Sidebar items={sidebarItems} />
          </aside>
        )}

        {/* Main content */}
        <main className={`flex-1 ${!isMobile ? "ml-64" : ""} p-4 lg:p-8 bg-gray-50`}>
          <div className="max-w-7xl mx-auto">
            {/* Page header */}
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold text-gray-800">{getPageTitle()}</h1>
                <p className="text-gray-500 text-sm mt-1">Track and manage your finances easily</p>
              </div>
            </div>

            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

export default Layout;
