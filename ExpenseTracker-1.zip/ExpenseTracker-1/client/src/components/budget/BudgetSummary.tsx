import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { formatRupiah, getBudgetProgressColorClass } from "@/utils/formatters";
import { Budget } from "@shared/schema";

interface BudgetSummaryProps {
  budgets: Budget[];
  isLoading: boolean;
}

const BudgetSummary: React.FC<BudgetSummaryProps> = ({ budgets, isLoading }) => {
  // Calculate summary data
  const totalBudget = budgets.reduce((sum, budget) => sum + budget.amount, 0);
  const totalSpent = budgets.reduce((sum, budget) => sum + budget.currentSpent, 0);
  const remainingBudget = totalBudget - totalSpent;
  
  // Get budget statuses by category
  const getBudgetStatuses = () => {
    return budgets.map(budget => {
      const percentUsed = budget.amount > 0 
        ? Math.min(100, Math.round((budget.currentSpent / budget.amount) * 100)) 
        : 0;
      
      let status = "Within budget";
      if (percentUsed >= 100) {
        status = "Over budget";
      } else if (percentUsed >= 80) {
        status = "Near limit";
      }
      
      return {
        category: budget.name,
        percentUsed,
        status,
        progressColor: getBudgetProgressColorClass(percentUsed)
      };
    });
  };

  if (isLoading) {
    return (
      <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-semibold text-gray-800">Budget Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-5">
            <div>
              <div className="space-y-2">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            </div>
            
            <div className="border-t border-gray-200 pt-4">
              <Skeleton className="h-4 w-48 mb-3" />
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => (
                  <div key={i}>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <Skeleton className="h-3 w-32" />
                      <Skeleton className="h-3 w-20" />
                    </div>
                    <Skeleton className="h-1.5 w-full rounded-full" />
                  </div>
                ))}
              </div>
            </div>
            
            <div className="border-t border-gray-200 pt-4">
              <Skeleton className="h-4 w-32 mb-3" />
              <Skeleton className="h-24 w-full rounded-lg" />
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const budgetStatuses = getBudgetStatuses();

  return (
    <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold text-gray-800">Budget Summary</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-5">
          <div>
            <div className="flex items-center justify-between text-sm font-medium mb-2">
              <span className="text-gray-600">Total Budget This Month</span>
              <span className="text-gray-800">{formatRupiah(totalBudget)}</span>
            </div>
            <div className="flex items-center justify-between text-sm font-medium mb-2">
              <span className="text-gray-600">Total Expenses</span>
              <span className="text-gray-800">{formatRupiah(totalSpent)}</span>
            </div>
            <div className="flex items-center justify-between text-sm font-medium mb-2">
              <span className="text-gray-600">Remaining Budget</span>
              <span className={remainingBudget >= 0 ? "text-success" : "text-danger"}>
                {formatRupiah(Math.abs(remainingBudget))}
                {remainingBudget < 0 && " (Overspent)"}
              </span>
            </div>
          </div>
          
          {budgetStatuses.length > 0 && (
            <div className="border-t border-gray-200 pt-4">
              <div className="text-sm font-medium text-gray-600 mb-3">Budget Status by Category</div>
              <div className="space-y-3">
                {budgetStatuses.map((item, index) => (
                  <div key={index}>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="text-gray-600">{item.category} ({item.percentUsed}%)</span>
                      <span className={
                        item.status === "Over budget" 
                          ? "text-danger font-medium" 
                          : item.status === "Near limit" 
                            ? "text-warning font-medium"
                            : "text-success font-medium"
                      }>
                        {item.status}
                      </span>
                    </div>
                    <Progress 
                      value={item.percentUsed} 
                      className="h-1.5 bg-gray-200" 
                      indicatorClassName={item.progressColor} 
                    />
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {budgets.some(b => b.currentSpent > b.amount) && (
            <div className="border-t border-gray-200 pt-4">
              <div className="text-sm font-medium text-gray-600 mb-3">Savings Tips</div>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-800">
                <p className="font-medium mb-1">Check your overspent categories</p>
                <p>
                  You have exceeded the budget in some categories. Consider reducing spending in these areas 
                  or adjusting your budget for the next period.
                </p>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default BudgetSummary;
