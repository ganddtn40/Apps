import React, { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { formatRupiah, formatDate, getBudgetStatusColorClass, getBudgetProgressColorClass } from "@/utils/formatters";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import IconBadge from "@/components/ui/IconBadge";
import {
  ShoppingBag,
  Utensils,
  Car,
  Film,
  Wifi,
  HomeIcon,
  Pencil,
  Trash,
  Calendar
} from "lucide-react";
import { Budget } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useMutation, useQueryClient } from "@tanstack/react-query";

interface BudgetListProps {
  budgets: Budget[];
  isLoading: boolean;
  onEditBudget: (budget: Budget) => void;
}

const iconMap = {
  "Food & Dining": { icon: Utensils, bgColor: "bg-blue-100", textColor: "text-blue-800" },
  "Transportation": { icon: Car, bgColor: "bg-green-100", textColor: "text-green-800" },
  "Entertainment": { icon: Film, bgColor: "bg-red-100", textColor: "text-red-800" },
  "Utilities": { icon: Wifi, bgColor: "bg-purple-100", textColor: "text-purple-800" },
  "Housing": { icon: HomeIcon, bgColor: "bg-indigo-100", textColor: "text-indigo-800" },
  "Shopping": { icon: ShoppingBag, bgColor: "bg-orange-100", textColor: "text-orange-800" }
};

const BudgetList: React.FC<BudgetListProps> = ({ 
  budgets, 
  isLoading,
  onEditBudget
}) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedBudget, setSelectedBudget] = useState<Budget | null>(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/budgets/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/budgets'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/summary'] });
      toast({
        title: "Budget deleted",
        description: "The budget has been deleted successfully.",
        variant: "default"
      });
      setShowDeleteDialog(false);
    },
    onError: (error) => {
      toast({
        title: "Failed to delete budget",
        description: (error as Error).message || "An error occurred while deleting the budget.",
        variant: "destructive"
      });
    }
  });

  const handleDeleteClick = (budget: Budget) => {
    setSelectedBudget(budget);
    setShowDeleteDialog(true);
  };

  const confirmDelete = () => {
    if (selectedBudget) {
      deleteMutation.mutate(selectedBudget.id);
    }
  };

  return (
    <Card className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      <CardHeader className="pb-2 px-6 pt-6">
        <CardTitle className="text-lg font-semibold text-gray-800">Current Budgets</CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="divide-y divide-gray-200">
          {isLoading ? (
            [...Array(3)].map((_, index) => (
              <div key={index} className="p-6">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center">
                      <Skeleton className="w-10 h-10 rounded-full mr-3" />
                      <div>
                        <Skeleton className="h-5 w-32 mb-1" />
                        <Skeleton className="h-4 w-40" />
                      </div>
                    </div>
                    <div className="mt-4">
                      <div className="flex items-center justify-between text-sm mb-1">
                        <Skeleton className="h-4 w-48" />
                        <Skeleton className="h-4 w-12" />
                      </div>
                      <Skeleton className="h-2 w-full rounded-full" />
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Skeleton className="h-9 w-16" />
                    <Skeleton className="h-9 w-16" />
                  </div>
                </div>
              </div>
            ))
          ) : budgets.length === 0 ? (
            <div className="p-6 text-center text-gray-500">
              No budgets found. Create a budget to get started.
            </div>
          ) : (
            budgets.map((budget) => {
              const { icon: Icon, bgColor, textColor } = 
                iconMap[budget.category as keyof typeof iconMap] || 
                { icon: ShoppingBag, bgColor: "bg-gray-100", textColor: "text-gray-800" };
              
              const percentUsed = budget.amount > 0 
                ? Math.min(100, Math.round((budget.currentSpent / budget.amount) * 100)) 
                : 0;
              
              const statusColor = getBudgetStatusColorClass(percentUsed);
              const progressColor = getBudgetProgressColorClass(percentUsed);
              
              let statusText = "Within budget";
              if (percentUsed >= 100) {
                statusText = "Over budget";
              } else if (percentUsed >= 80) {
                statusText = "Near limit";
              }
              
              return (
                <div key={budget.id} className="p-6">
                  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center">
                        <IconBadge
                          icon={Icon}
                          bgColor={bgColor}
                          textColor={textColor}
                          className="mr-3"
                        />
                        <div>
                          <h4 className="text-lg font-medium text-gray-800">{budget.name}</h4>
                          <div className="flex items-center text-sm text-gray-500 mt-1">
                            <span className="flex items-center">
                              <Calendar className="mr-1 h-4 w-4" />
                              {formatDate(budget.startDate)}
                            </span>
                            <span className="mx-2">•</span>
                            <span className={`flex items-center ${statusColor} font-medium`}>
                              {statusText}
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="mt-4">
                        <div className="flex items-center justify-between text-sm mb-1">
                          <div>
                            <span className="font-medium text-gray-700">{formatRupiah(budget.currentSpent)}</span>
                            <span className="text-gray-500"> of </span>
                            <span className="font-medium text-gray-700">{formatRupiah(budget.amount)}</span>
                          </div>
                          <span className={`font-medium ${statusColor}`}>{percentUsed}%</span>
                        </div>
                        <Progress value={percentUsed} className="h-2 bg-gray-200" indicatorClassName={progressColor} />
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onEditBudget(budget)}
                      >
                        <Pencil className="mr-1 h-4 w-4" />
                        Edit
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-red-500 hover:text-red-700"
                        onClick={() => handleDeleteClick(budget)}
                      >
                        <Trash className="mr-1 h-4 w-4" />
                        Delete
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </CardContent>

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Budget</DialogTitle>
          </DialogHeader>
          <p className="py-4">
            Are you sure you want to delete this budget? This action cannot be undone.
          </p>
          {selectedBudget && (
            <div className="my-2 p-4 bg-gray-50 rounded-md">
              <p><strong>Name:</strong> {selectedBudget.name}</p>
              <p><strong>Amount:</strong> {formatRupiah(selectedBudget.amount)}</p>
              <p><strong>Category:</strong> {selectedBudget.category}</p>
            </div>
          )}
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Cancel</Button>
            </DialogClose>
            <Button 
              variant="destructive" 
              onClick={confirmDelete}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
};

export default BudgetList;
