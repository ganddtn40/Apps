/**
 * Format a number as Indonesian Rupiah
 */
export const formatRupiah = (amount: number): string => {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
};

/**
 * Format date to localized string (e.g., "24 Jun 2023")
 */
export const formatDate = (date: Date | string): string => {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  return dateObj.toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  });
};

/**
 * Format date to include time (e.g., "24 Jun 2023, 14:30")
 */
export const formatDateTime = (date: Date | string): string => {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  return dateObj.toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
};

/**
 * Get relative time from now (e.g., "2 days ago", "Today", etc.)
 */
export const getRelativeTime = (date: Date | string): string => {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  const now = new Date();
  
  const diffInMs = now.getTime() - dateObj.getTime();
  const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24));
  
  if (diffInDays === 0) {
    return 'Today';
  } else if (diffInDays === 1) {
    return 'Yesterday';
  } else if (diffInDays < 7) {
    return `${diffInDays} days ago`;
  } else {
    return formatDate(dateObj);
  }
};

/**
 * Format percentage (e.g., 75.5 -> "75.5%")
 */
export const formatPercentage = (value: number): string => {
  return `${value.toFixed(1)}%`;
};

/**
 * Get days until a given date
 */
export const getDaysUntil = (date: Date | string): number => {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  const now = new Date();
  
  // Reset time to compare dates only
  now.setHours(0, 0, 0, 0);
  const compareDate = new Date(dateObj);
  compareDate.setHours(0, 0, 0, 0);
  
  const diffInMs = compareDate.getTime() - now.getTime();
  return Math.ceil(diffInMs / (1000 * 60 * 60 * 24));
};

/**
 * Get a text representation of days until a date
 */
export const getDaysUntilText = (date: Date | string): string => {
  const days = getDaysUntil(date);
  
  if (days < 0) {
    return `${Math.abs(days)} days overdue`;
  } else if (days === 0) {
    return 'Due today';
  } else if (days === 1) {
    return 'Due tomorrow';
  } else {
    return `Due in ${days} days`;
  }
};

/**
 * Get color class based on percentage of budget used
 */
export const getBudgetStatusColorClass = (percentUsed: number): string => {
  if (percentUsed >= 100) {
    return 'text-danger';
  } else if (percentUsed >= 80) {
    return 'text-warning';
  } else {
    return 'text-success';
  }
};

/**
 * Get progress bar color class based on percentage of budget used
 */
export const getBudgetProgressColorClass = (percentUsed: number): string => {
  if (percentUsed >= 100) {
    return 'bg-danger';
  } else if (percentUsed >= 80) {
    return 'bg-warning';
  } else {
    return 'bg-success';
  }
};

/**
 * Get background and foreground color classes for category badge
 */
export const getCategoryColorClasses = (category: string): { bg: string; text: string } => {
  switch (category) {
    case 'Food & Dining':
      return { bg: 'bg-blue-100', text: 'text-blue-800' };
    case 'Transportation':
      return { bg: 'bg-green-100', text: 'text-green-800' };
    case 'Entertainment':
      return { bg: 'bg-red-100', text: 'text-red-800' };
    case 'Utilities':
      return { bg: 'bg-purple-100', text: 'text-purple-800' };
    case 'Housing':
      return { bg: 'bg-indigo-100', text: 'text-indigo-800' };
    case 'Health & Medical':
      return { bg: 'bg-pink-100', text: 'text-pink-800' };
    case 'Education':
      return { bg: 'bg-yellow-100', text: 'text-yellow-800' };
    case 'Shopping':
      return { bg: 'bg-orange-100', text: 'text-orange-800' };
    default:
      return { bg: 'bg-gray-100', text: 'text-gray-800' };
  }
};

/**
 * Get icon classes for different expense categories
 */
export const getCategoryIcon = (category: string): string => {
  switch (category) {
    case 'Food & Dining':
      return 'ri-restaurant-line';
    case 'Transportation':
      return 'ri-car-line';
    case 'Entertainment':
      return 'ri-movie-2-line';
    case 'Utilities':
      return 'ri-lightbulb-line';
    case 'Housing':
      return 'ri-home-line';
    case 'Health & Medical':
      return 'ri-heart-pulse-line';
    case 'Education':
      return 'ri-book-open-line';
    case 'Shopping':
      return 'ri-shopping-bag-line';
    default:
      return 'ri-question-line';
  }
};
