import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { PlusCircle } from "lucide-react";
import BillList from "@/components/bill/BillList";
import BillSummary from "@/components/bill/BillSummary";
import AddBillForm from "@/components/bill/AddBillForm";
import { Bill } from "@shared/schema";

const Bills = () => {
  const [showBillForm, setShowBillForm] = useState(false);
  const [editingBill, setEditingBill] = useState<Bill | null>(null);

  // Fetch bills data
  const { data: bills, isLoading } = useQuery<Bill[]>({
    queryKey: ['/api/bills'],
  });

  // Function to open edit form
  const handleEditBill = (bill: Bill) => {
    setEditingBill(bill);
    setShowBillForm(true);
  };

  return (
    <>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Bills</h1>
          <p className="text-gray-500 text-sm mt-1">Track your upcoming payments</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button 
            onClick={() => {
              setEditingBill(null);
              setShowBillForm(true);
            }}
            className="inline-flex items-center"
          >
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Bill
          </Button>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        <div className="w-full lg:w-2/3">
          <BillList 
            bills={bills || []}
            isLoading={isLoading}
            onEditBill={handleEditBill}
          />
        </div>
        
        <div className="w-full lg:w-1/3 space-y-6">
          <BillSummary 
            bills={bills || []}
            isLoading={isLoading}
          />
        </div>
      </div>

      <AddBillForm 
        open={showBillForm} 
        onOpenChange={setShowBillForm}
        initialData={editingBill}
        isEditing={!!editingBill}
      />
    </>
  );
};

export default Bills;
