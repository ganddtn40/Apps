import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { PlusCircle } from "lucide-react";
import ExpenseTable from "@/components/expense/ExpenseTable";
import AddExpenseForm from "@/components/expense/AddExpenseForm";
import { Expense, InsertExpense } from "@shared/schema";

const Expenses = () => {
  const [showExpenseForm, setShowExpenseForm] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [periodFilter, setPeriodFilter] = useState("thisMonth");

  // Calculate date range based on period filter
  const getDateRange = () => {
    const now = new Date();
    let startDate = new Date(now.getFullYear(), now.getMonth(), 1); // Start of current month
    
    if (periodFilter === "lastMonth") {
      startDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    } else if (periodFilter === "3months") {
      startDate = new Date(now.getFullYear(), now.getMonth() - 3, 1);
    } else if (periodFilter === "thisYear") {
      startDate = new Date(now.getFullYear(), 0, 1);
    }
    
    return { startDate, endDate: now };
  };
  
  // Query expenses with potential filters
  const { data: expenses, isLoading } = useQuery<Expense[]>({
    queryKey: ['/api/expenses', categoryFilter, periodFilter],
  });

  // Function to open edit form
  const handleEditExpense = (expense: Expense) => {
    setEditingExpense(expense);
    setShowExpenseForm(true);
  };

  // Filter expenses based on search term, category, and period
  const filteredExpenses = expenses ? expenses.filter(expense => {
    // Search term filter (case insensitive)
    const matchesSearch = searchTerm === "" || 
      expense.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      expense.category.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Category filter
    const matchesCategory = categoryFilter === "" || expense.category === categoryFilter;
    
    // Period filter (already handled in query, but we could add additional filtering here)
    
    return matchesSearch && matchesCategory;
  }) : [];

  return (
    <>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Expenses</h1>
          <p className="text-gray-500 text-sm mt-1">Track and manage your spending</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button 
            onClick={() => {
              setEditingExpense(null);
              setShowExpenseForm(true);
            }}
            className="inline-flex items-center"
          >
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Expense
          </Button>
        </div>
      </div>

      <ExpenseTable 
        expenses={filteredExpenses}
        isLoading={isLoading}
        onEditExpense={handleEditExpense}
        onSearch={setSearchTerm}
        onCategoryFilter={setCategoryFilter}
        onPeriodFilter={setPeriodFilter}
      />

      <AddExpenseForm 
        open={showExpenseForm} 
        onOpenChange={setShowExpenseForm}
        initialData={editingExpense}
        isEditing={!!editingExpense}
      />
    </>
  );
};

export default Expenses;
