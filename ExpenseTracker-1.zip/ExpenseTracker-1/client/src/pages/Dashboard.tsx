import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PlusCircle, Wallet } from "lucide-react";
import TotalExpenseCard from "@/components/overview/TotalExpenseCard";
import BudgetStatusCard from "@/components/overview/BudgetStatusCard";
import SavingsCard from "@/components/overview/SavingsCard";
import UpcomingBillsCard from "@/components/overview/UpcomingBillsCard";
import RecentTransactions from "@/components/overview/RecentTransactions";
import CategoryChart from "@/components/overview/CategoryChart";
import MonthlyChart from "@/components/overview/MonthlyChart";
import SpendingTrend from "@/components/overview/SpendingTrend";
import AddExpenseForm from "@/components/expense/AddExpenseForm";
import AddBudgetForm from "@/components/budget/AddBudgetForm";
import { InsertExpense, InsertBudget } from "@shared/schema";

const Dashboard = () => {
  const [activeTab, setActiveTab] = useState("overview");
  const [showExpenseForm, setShowExpenseForm] = useState(false);
  const [showBudgetForm, setShowBudgetForm] = useState(false);

  // Fetch dashboard summary data
  const { data: summary, isLoading } = useQuery({
    queryKey: ['/api/dashboard/summary'],
    refetchInterval: 60000, // Refresh every minute
  });

  // Process category data for chart
  const getCategoryChartData = () => {
    if (!summary || !summary.expensesByCategory) return [];
    
    const COLORS = ['#2563eb', '#4ade80', '#facc15', '#f43f5e', '#94a3b8', '#8b5cf6', '#ec4899', '#f97316'];
    
    return Object.entries(summary.expensesByCategory).map(([name, value], index) => ({
      name,
      value: value as number,
      color: COLORS[index % COLORS.length]
    }));
  };

  // Calculate total for category chart
  const getCategoryTotal = () => {
    if (!summary || !summary.expensesByCategory) return 0;
    return Object.values(summary.expensesByCategory).reduce((sum, value) => sum + (value as number), 0);
  };

  return (
    <>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Dashboard</h1>
          <p className="text-gray-500 text-sm mt-1">Track and manage your finances easily</p>
        </div>
        <div className="mt-4 md:mt-0 flex flex-col sm:flex-row gap-3">
          <Button 
            onClick={() => setShowExpenseForm(true)}
            className="inline-flex items-center"
          >
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Expense
          </Button>
          <Button 
            onClick={() => setShowBudgetForm(true)}
            variant="outline"
            className="inline-flex items-center"
          >
            <Wallet className="mr-2 h-4 w-4" />
            Set Budget
          </Button>
        </div>
      </div>

      {/* Overview cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <TotalExpenseCard 
          amount={summary?.totalExpenses.amount || 0}
          percentChange={summary?.totalExpenses.percentChange || 0}
          isLoading={isLoading}
        />
        <BudgetStatusCard 
          totalAmount={summary?.budgetStatus.totalAmount || 0}
          remainingAmount={summary?.budgetStatus.remaining || 0}
          percentUsed={summary?.budgetStatus.percentUsed || 0}
          isLoading={isLoading}
        />
        <SavingsCard 
          targetAmount={5000000} // Example target
          currentAmount={summary?.budgetStatus.remaining || 0}
          percentReached={summary?.budgetStatus.remaining ? (summary.budgetStatus.remaining / 5000000) * 100 : 0}
          isLoading={isLoading}
        />
        <UpcomingBillsCard 
          totalAmount={summary?.upcomingBills.amount || 0}
          count={summary?.upcomingBills.count || 0}
          daysUntilNext={7}
          isLoading={isLoading}
        />
      </div>

      {/* Main content tabs */}
      <Tabs defaultValue="overview" onValueChange={setActiveTab} className="mb-8">
        <TabsList className="border-b border-gray-200 w-full justify-start rounded-none bg-transparent mb-6">
          <TabsTrigger 
            value="overview" 
            className={`pb-4 px-1 text-sm font-medium border-b-2 rounded-none ${
              activeTab === "overview" 
                ? "text-primary border-primary" 
                : "text-gray-500 border-transparent"
            }`}
          >
            Overview
          </TabsTrigger>
          <TabsTrigger 
            value="expenses" 
            className={`pb-4 px-1 text-sm font-medium border-b-2 rounded-none ${
              activeTab === "expenses" 
                ? "text-primary border-primary" 
                : "text-gray-500 border-transparent"
            }`}
          >
            Expenses
          </TabsTrigger>
          <TabsTrigger 
            value="budgets" 
            className={`pb-4 px-1 text-sm font-medium border-b-2 rounded-none ${
              activeTab === "budgets" 
                ? "text-primary border-primary" 
                : "text-gray-500 border-transparent"
            }`}
          >
            Budgets
          </TabsTrigger>
          <TabsTrigger 
            value="bills" 
            className={`pb-4 px-1 text-sm font-medium border-b-2 rounded-none ${
              activeTab === "bills" 
                ? "text-primary border-primary" 
                : "text-gray-500 border-transparent"
            }`}
          >
            Bills
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
            {/* Monthly spending chart */}
            <div className="lg:col-span-2">
              <MonthlyChart 
                data={summary?.monthlySpending || []} 
                isLoading={isLoading}
              />
            </div>

            {/* Expense by category */}
            <div>
              <CategoryChart 
                data={getCategoryChartData()} 
                total={getCategoryTotal()}
                isLoading={isLoading}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Recent transactions */}
            <div className="lg:col-span-2">
              <RecentTransactions 
                transactions={summary?.recentTransactions || []}
                isLoading={isLoading} 
              />
            </div>

            {/* Spending trend & upcoming bills */}
            <div className="space-y-6">
              {/* Daily spending trend */}
              <SpendingTrend 
                data={summary?.dailySpending || []}
                isLoading={isLoading}
              />

              {/* Upcoming bills section could go here */}
              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-800">Upcoming Bills</h3>
                  <a href="/bills" className="text-primary text-sm font-medium">View All</a>
                </div>
                <div className="space-y-4">
                  {isLoading ? (
                    [...Array(3)].map((_, index) => (
                      <div key={index} className="animate-pulse flex items-center justify-between py-2">
                        <div className="flex items-center">
                          <div className="w-10 h-10 rounded-full bg-gray-200 mr-3"></div>
                          <div>
                            <div className="h-4 bg-gray-200 rounded w-24 mb-1"></div>
                            <div className="h-3 bg-gray-200 rounded w-20"></div>
                          </div>
                        </div>
                        <div className="h-4 bg-gray-200 rounded w-20"></div>
                      </div>
                    ))
                  ) : !summary?.upcomingBills.bills || summary.upcomingBills.bills.length === 0 ? (
                    <div className="text-center py-4 text-gray-500">
                      No upcoming bills
                    </div>
                  ) : (
                    summary.upcomingBills.bills.slice(0, 3).map((bill: any) => (
                      <div key={bill.id} className="flex items-center justify-between py-2">
                        <div className="flex items-center">
                          <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center text-danger mr-3">
                            <i className="ri-bill-line"></i>
                          </div>
                          <div>
                            <p className="font-medium text-gray-800">{bill.name}</p>
                            <p className="text-xs text-danger">Due in {new Date(bill.dueDate).getDate() - new Date().getDate()} days</p>
                          </div>
                        </div>
                        <p className="font-medium text-gray-800">Rp {bill.amount.toLocaleString()}</p>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="expenses">
          <div className="p-4 text-center">
            <h3 className="text-lg font-medium mb-2">View Expenses</h3>
            <p className="text-gray-500 mb-4">Go to the Expenses page for a detailed view of all your transactions</p>
            <Button asChild>
              <a href="/expenses">View All Expenses</a>
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="budgets">
          <div className="p-4 text-center">
            <h3 className="text-lg font-medium mb-2">Manage Budgets</h3>
            <p className="text-gray-500 mb-4">Go to the Budgets page to create and manage your spending limits</p>
            <Button asChild>
              <a href="/budgets">View All Budgets</a>
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="bills">
          <div className="p-4 text-center">
            <h3 className="text-lg font-medium mb-2">Upcoming Bills</h3>
            <p className="text-gray-500 mb-4">Go to the Bills page to track your upcoming payments</p>
            <Button asChild>
              <a href="/bills">View All Bills</a>
            </Button>
          </div>
        </TabsContent>
      </Tabs>

      {/* Modals */}
      <AddExpenseForm 
        open={showExpenseForm} 
        onOpenChange={setShowExpenseForm} 
      />
      
      <AddBudgetForm 
        open={showBudgetForm} 
        onOpenChange={setShowBudgetForm} 
      />
    </>
  );
};

export default Dashboard;
