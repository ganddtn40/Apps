import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { PlusCircle } from "lucide-react";
import BudgetList from "@/components/budget/BudgetList";
import BudgetSummary from "@/components/budget/BudgetSummary";
import AddBudgetForm from "@/components/budget/AddBudgetForm";
import { Budget } from "@shared/schema";

const Budgets = () => {
  const [showBudgetForm, setShowBudgetForm] = useState(false);
  const [editingBudget, setEditingBudget] = useState<Budget | null>(null);

  // Fetch budgets data
  const { data: budgets, isLoading } = useQuery<Budget[]>({
    queryKey: ['/api/budgets'],
  });

  // Function to open edit form
  const handleEditBudget = (budget: Budget) => {
    setEditingBudget(budget);
    setShowBudgetForm(true);
  };

  return (
    <>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Budgets</h1>
          <p className="text-gray-500 text-sm mt-1">Create and manage your spending limits</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button 
            onClick={() => {
              setEditingBudget(null);
              setShowBudgetForm(true);
            }}
            className="inline-flex items-center"
          >
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Budget
          </Button>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        <div className="w-full lg:w-2/3">
          <BudgetList 
            budgets={budgets || []}
            isLoading={isLoading}
            onEditBudget={handleEditBudget}
          />
        </div>
        
        <div className="w-full lg:w-1/3">
          <BudgetSummary 
            budgets={budgets || []}
            isLoading={isLoading}
          />
        </div>
      </div>

      <AddBudgetForm 
        open={showBudgetForm} 
        onOpenChange={setShowBudgetForm}
        initialData={editingBudget}
        isEditing={!!editingBudget}
      />
    </>
  );
};

export default Budgets;
