import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  expenseSchema, 
  budgetSchema, 
  billSchema
} from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  const apiRouter = app.route('/api');
  
  // Error handling middleware
  app.use((err: Error, req: any, res: any, next: any) => {
    console.error(err.stack);
    
    if (err instanceof ZodError) {
      const validationError = fromZodError(err);
      return res.status(400).json({ 
        message: 'Validation error', 
        errors: validationError.details 
      });
    }
    
    return res.status(500).json({ message: 'Internal server error' });
  });

  // Expense Routes
  app.get('/api/expenses', async (req, res) => {
    try {
      const expenses = await storage.getExpenses();
      res.json(expenses);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch expenses' });
    }
  });
  
  app.get('/api/expenses/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const expense = await storage.getExpenseById(id);
      
      if (!expense) {
        return res.status(404).json({ message: 'Expense not found' });
      }
      
      res.json(expense);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch expense' });
    }
  });
  
  app.post('/api/expenses', async (req, res) => {
    try {
      const expenseData = expenseSchema.parse(req.body);
      const expense = await storage.createExpense(expenseData);
      res.status(201).json(expense);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ 
          message: 'Validation error', 
          errors: validationError.details 
        });
      }
      res.status(500).json({ message: 'Failed to create expense' });
    }
  });
  
  app.put('/api/expenses/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const expenseData = expenseSchema.parse(req.body);
      const expense = await storage.updateExpense(id, expenseData);
      
      if (!expense) {
        return res.status(404).json({ message: 'Expense not found' });
      }
      
      res.json(expense);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ 
          message: 'Validation error', 
          errors: validationError.details 
        });
      }
      res.status(500).json({ message: 'Failed to update expense' });
    }
  });
  
  app.delete('/api/expenses/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteExpense(id);
      
      if (!success) {
        return res.status(404).json({ message: 'Expense not found' });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete expense' });
    }
  });
  
  // Budget Routes
  app.get('/api/budgets', async (req, res) => {
    try {
      const budgets = await storage.getBudgets();
      res.json(budgets);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch budgets' });
    }
  });
  
  app.get('/api/budgets/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const budget = await storage.getBudgetById(id);
      
      if (!budget) {
        return res.status(404).json({ message: 'Budget not found' });
      }
      
      res.json(budget);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch budget' });
    }
  });
  
  app.post('/api/budgets', async (req, res) => {
    try {
      const budgetData = budgetSchema.parse(req.body);
      const budget = await storage.createBudget(budgetData);
      res.status(201).json(budget);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ 
          message: 'Validation error', 
          errors: validationError.details 
        });
      }
      res.status(500).json({ message: 'Failed to create budget' });
    }
  });
  
  app.put('/api/budgets/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const budgetData = budgetSchema.parse(req.body);
      const budget = await storage.updateBudget(id, budgetData);
      
      if (!budget) {
        return res.status(404).json({ message: 'Budget not found' });
      }
      
      res.json(budget);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ 
          message: 'Validation error', 
          errors: validationError.details 
        });
      }
      res.status(500).json({ message: 'Failed to update budget' });
    }
  });
  
  app.delete('/api/budgets/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteBudget(id);
      
      if (!success) {
        return res.status(404).json({ message: 'Budget not found' });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete budget' });
    }
  });
  
  // Bill Routes
  app.get('/api/bills', async (req, res) => {
    try {
      const bills = await storage.getBills();
      res.json(bills);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch bills' });
    }
  });
  
  app.get('/api/bills/upcoming', async (req, res) => {
    try {
      const daysAhead = parseInt(req.query.days as string) || 7;
      const bills = await storage.getUpcomingBills(daysAhead);
      res.json(bills);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch upcoming bills' });
    }
  });
  
  app.get('/api/bills/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const bill = await storage.getBillById(id);
      
      if (!bill) {
        return res.status(404).json({ message: 'Bill not found' });
      }
      
      res.json(bill);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch bill' });
    }
  });
  
  app.post('/api/bills', async (req, res) => {
    try {
      const billData = billSchema.parse(req.body);
      const bill = await storage.createBill(billData);
      res.status(201).json(bill);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ 
          message: 'Validation error', 
          errors: validationError.details 
        });
      }
      res.status(500).json({ message: 'Failed to create bill' });
    }
  });
  
  app.put('/api/bills/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const billData = billSchema.parse(req.body);
      const bill = await storage.updateBill(id, billData);
      
      if (!bill) {
        return res.status(404).json({ message: 'Bill not found' });
      }
      
      res.json(bill);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ 
          message: 'Validation error', 
          errors: validationError.details 
        });
      }
      res.status(500).json({ message: 'Failed to update bill' });
    }
  });
  
  app.patch('/api/bills/:id/pay', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const isPaid = req.body.isPaid === true;
      const bill = await storage.markBillAsPaid(id, isPaid);
      
      if (!bill) {
        return res.status(404).json({ message: 'Bill not found' });
      }
      
      res.json(bill);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update bill payment status' });
    }
  });
  
  app.delete('/api/bills/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteBill(id);
      
      if (!success) {
        return res.status(404).json({ message: 'Bill not found' });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete bill' });
    }
  });
  
  // Dashboard summary
  app.get('/api/dashboard/summary', async (req, res) => {
    try {
      const expenses = await storage.getExpenses();
      const budgets = await storage.getBudgets();
      const upcomingBills = await storage.getUpcomingBills(7);
      
      // Calculate total expenses for current month
      const now = new Date();
      const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const lastDayOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);
      
      const monthlyExpenses = expenses.filter(expense => {
        const expenseDate = new Date(expense.date);
        return expenseDate >= firstDayOfMonth && expenseDate <= lastDayOfMonth;
      });
      
      const totalExpensesThisMonth = monthlyExpenses.reduce((sum, expense) => sum + expense.amount, 0);
      
      // Calculate previous month's expenses for comparison
      const firstDayOfPrevMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const lastDayOfPrevMonth = new Date(now.getFullYear(), now.getMonth(), 0);
      
      const prevMonthExpenses = expenses.filter(expense => {
        const expenseDate = new Date(expense.date);
        return expenseDate >= firstDayOfPrevMonth && expenseDate <= lastDayOfPrevMonth;
      });
      
      const totalExpensesPrevMonth = prevMonthExpenses.reduce((sum, expense) => sum + expense.amount, 0);
      
      // Calculate percentage change
      let percentChange = 0;
      if (totalExpensesPrevMonth > 0) {
        percentChange = ((totalExpensesThisMonth - totalExpensesPrevMonth) / totalExpensesPrevMonth) * 100;
      }
      
      // Calculate total budget amount and remaining
      const totalBudgetAmount = budgets.reduce((sum, budget) => sum + budget.amount, 0);
      const totalBudgetSpent = budgets.reduce((sum, budget) => sum + budget.currentSpent, 0);
      const budgetRemaining = totalBudgetAmount - totalBudgetSpent;
      const budgetPercentUsed = totalBudgetAmount > 0 
        ? (totalBudgetSpent / totalBudgetAmount) * 100 
        : 0;
      
      // Get recent transactions
      const recentTransactions = expenses.slice(0, 5);
      
      // Calculate expenses by category
      const expensesByCategory = {};
      expenses.forEach(expense => {
        if (!expensesByCategory[expense.category]) {
          expensesByCategory[expense.category] = 0;
        }
        expensesByCategory[expense.category] += expense.amount;
      });
      
      // Calculate monthly spending for last 6 months
      const monthlySpending = [];
      for (let i = 5; i >= 0; i--) {
        const startDate = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const endDate = new Date(now.getFullYear(), now.getMonth() - i + 1, 0);
        
        const monthExpenses = expenses.filter(expense => {
          const expenseDate = new Date(expense.date);
          return expenseDate >= startDate && expenseDate <= endDate;
        });
        
        const totalForMonth = monthExpenses.reduce((sum, expense) => sum + expense.amount, 0);
        
        monthlySpending.push({
          month: startDate.toLocaleString('default', { month: 'short' }),
          amount: totalForMonth
        });
      }
      
      // Calculate daily spending trend for current week
      const dailySpending = [];
      for (let i = 6; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        date.setHours(0, 0, 0, 0);
        
        const nextDay = new Date(date);
        nextDay.setDate(nextDay.getDate() + 1);
        
        const dayExpenses = expenses.filter(expense => {
          const expenseDate = new Date(expense.date);
          return expenseDate >= date && expenseDate < nextDay;
        });
        
        const totalForDay = dayExpenses.reduce((sum, expense) => sum + expense.amount, 0);
        
        dailySpending.push({
          day: date.toLocaleString('default', { weekday: 'short' }),
          amount: totalForDay
        });
      }
      
      // Total upcoming bills amount
      const totalUpcomingBillsAmount = upcomingBills.reduce((sum, bill) => sum + bill.amount, 0);
      
      // Response object
      const summary = {
        totalExpenses: {
          amount: totalExpensesThisMonth,
          percentChange,
          trend: percentChange >= 0 ? 'increase' : 'decrease'
        },
        budgetStatus: {
          totalAmount: totalBudgetAmount,
          spent: totalBudgetSpent,
          remaining: budgetRemaining,
          percentUsed: budgetPercentUsed
        },
        upcomingBills: {
          count: upcomingBills.length,
          amount: totalUpcomingBillsAmount,
          bills: upcomingBills
        },
        recentTransactions,
        expensesByCategory,
        monthlySpending,
        dailySpending
      };
      
      res.json(summary);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Failed to fetch dashboard summary' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
