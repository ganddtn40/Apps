import { 
  expenses, type Expense, type InsertExpense,
  budgets, type Budget, type InsertBudget,
  bills, type Bill, type InsertBill,
  users, type User, type InsertUser
} from "@shared/schema";

// Storage interface for all our data operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Expense operations
  getExpenses(): Promise<Expense[]>;
  getExpenseById(id: number): Promise<Expense | undefined>;
  getExpensesByCategory(category: string): Promise<Expense[]>;
  getExpensesByDateRange(startDate: Date, endDate: Date): Promise<Expense[]>;
  createExpense(expense: InsertExpense): Promise<Expense>;
  updateExpense(id: number, expense: Partial<InsertExpense>): Promise<Expense | undefined>;
  deleteExpense(id: number): Promise<boolean>;
  
  // Budget operations
  getBudgets(): Promise<Budget[]>;
  getBudgetById(id: number): Promise<Budget | undefined>;
  getBudgetByCategory(category: string): Promise<Budget | undefined>;
  createBudget(budget: InsertBudget): Promise<Budget>;
  updateBudget(id: number, budget: Partial<InsertBudget>): Promise<Budget | undefined>;
  updateBudgetSpending(id: number, spent: number): Promise<Budget | undefined>;
  deleteBudget(id: number): Promise<boolean>;
  
  // Bill operations
  getBills(): Promise<Bill[]>;
  getBillById(id: number): Promise<Bill | undefined>;
  getUpcomingBills(daysAhead: number): Promise<Bill[]>;
  createBill(bill: InsertBill): Promise<Bill>;
  updateBill(id: number, bill: Partial<InsertBill>): Promise<Bill | undefined>;
  markBillAsPaid(id: number, isPaid: boolean): Promise<Bill | undefined>;
  deleteBill(id: number): Promise<boolean>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private expensesStore: Map<number, Expense>;
  private budgetsStore: Map<number, Budget>;
  private billsStore: Map<number, Bill>;
  
  private userId: number = 1;
  private expenseId: number = 1;
  private budgetId: number = 1;
  private billId: number = 1;

  constructor() {
    this.users = new Map();
    this.expensesStore = new Map();
    this.budgetsStore = new Map();
    this.billsStore = new Map();
    
    // Initialize with some sample data
    this.initializeSampleData();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Expense operations
  async getExpenses(): Promise<Expense[]> {
    return Array.from(this.expensesStore.values()).sort((a, b) => 
      new Date(b.date).getTime() - new Date(a.date).getTime()
    );
  }
  
  async getExpenseById(id: number): Promise<Expense | undefined> {
    return this.expensesStore.get(id);
  }
  
  async getExpensesByCategory(category: string): Promise<Expense[]> {
    return Array.from(this.expensesStore.values())
      .filter(expense => expense.category === category)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }
  
  async getExpensesByDateRange(startDate: Date, endDate: Date): Promise<Expense[]> {
    return Array.from(this.expensesStore.values())
      .filter(expense => {
        const expenseDate = new Date(expense.date);
        return expenseDate >= startDate && expenseDate <= endDate;
      })
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }
  
  async createExpense(insertExpense: InsertExpense): Promise<Expense> {
    const id = this.expenseId++;
    const expense: Expense = { ...insertExpense, id };
    this.expensesStore.set(id, expense);
    
    // Update budget spending for the category if exists
    const budget = Array.from(this.budgetsStore.values())
      .find(b => b.category === expense.category);
      
    if (budget) {
      budget.currentSpent += expense.amount;
      this.budgetsStore.set(budget.id, budget);
    }
    
    return expense;
  }
  
  async updateExpense(id: number, expenseUpdate: Partial<InsertExpense>): Promise<Expense | undefined> {
    const expense = this.expensesStore.get(id);
    if (!expense) return undefined;
    
    const previousAmount = expense.amount;
    const previousCategory = expense.category;
    
    // Update expense
    const updatedExpense = { ...expense, ...expenseUpdate };
    this.expensesStore.set(id, updatedExpense);
    
    // If amount or category changed, update budget spending
    if (previousAmount !== updatedExpense.amount || previousCategory !== updatedExpense.category) {
      // Remove from previous category budget
      if (previousCategory) {
        const previousBudget = Array.from(this.budgetsStore.values())
          .find(b => b.category === previousCategory);
        
        if (previousBudget) {
          previousBudget.currentSpent -= previousAmount;
          this.budgetsStore.set(previousBudget.id, previousBudget);
        }
      }
      
      // Add to new category budget
      const newBudget = Array.from(this.budgetsStore.values())
        .find(b => b.category === updatedExpense.category);
        
      if (newBudget) {
        newBudget.currentSpent += updatedExpense.amount;
        this.budgetsStore.set(newBudget.id, newBudget);
      }
    }
    
    return updatedExpense;
  }
  
  async deleteExpense(id: number): Promise<boolean> {
    const expense = this.expensesStore.get(id);
    if (!expense) return false;
    
    // Update budget spending
    const budget = Array.from(this.budgetsStore.values())
      .find(b => b.category === expense.category);
      
    if (budget) {
      budget.currentSpent -= expense.amount;
      this.budgetsStore.set(budget.id, budget);
    }
    
    return this.expensesStore.delete(id);
  }
  
  // Budget operations
  async getBudgets(): Promise<Budget[]> {
    return Array.from(this.budgetsStore.values());
  }
  
  async getBudgetById(id: number): Promise<Budget | undefined> {
    return this.budgetsStore.get(id);
  }
  
  async getBudgetByCategory(category: string): Promise<Budget | undefined> {
    return Array.from(this.budgetsStore.values())
      .find(budget => budget.category === category);
  }
  
  async createBudget(insertBudget: InsertBudget): Promise<Budget> {
    const id = this.budgetId++;
    
    // Calculate current spending for this category
    const currentSpent = Array.from(this.expensesStore.values())
      .filter(expense => expense.category === insertBudget.category)
      .reduce((sum, expense) => sum + expense.amount, 0);
    
    const budget: Budget = { ...insertBudget, id, currentSpent };
    this.budgetsStore.set(id, budget);
    return budget;
  }
  
  async updateBudget(id: number, budgetUpdate: Partial<InsertBudget>): Promise<Budget | undefined> {
    const budget = this.budgetsStore.get(id);
    if (!budget) return undefined;
    
    // Update budget
    const updatedBudget: Budget = { ...budget, ...budgetUpdate };
    this.budgetsStore.set(id, updatedBudget);
    return updatedBudget;
  }
  
  async updateBudgetSpending(id: number, spent: number): Promise<Budget | undefined> {
    const budget = this.budgetsStore.get(id);
    if (!budget) return undefined;
    
    budget.currentSpent = spent;
    this.budgetsStore.set(id, budget);
    return budget;
  }
  
  async deleteBudget(id: number): Promise<boolean> {
    return this.budgetsStore.delete(id);
  }
  
  // Bill operations
  async getBills(): Promise<Bill[]> {
    return Array.from(this.billsStore.values())
      .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());
  }
  
  async getBillById(id: number): Promise<Bill | undefined> {
    return this.billsStore.get(id);
  }
  
  async getUpcomingBills(daysAhead: number): Promise<Bill[]> {
    const today = new Date();
    const futureDate = new Date();
    futureDate.setDate(today.getDate() + daysAhead);
    
    return Array.from(this.billsStore.values())
      .filter(bill => {
        if (bill.isPaid) return false;
        const dueDate = new Date(bill.dueDate);
        return dueDate >= today && dueDate <= futureDate;
      })
      .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());
  }
  
  async createBill(insertBill: InsertBill): Promise<Bill> {
    const id = this.billId++;
    const bill: Bill = { ...insertBill, id };
    this.billsStore.set(id, bill);
    return bill;
  }
  
  async updateBill(id: number, billUpdate: Partial<InsertBill>): Promise<Bill | undefined> {
    const bill = this.billsStore.get(id);
    if (!bill) return undefined;
    
    const updatedBill: Bill = { ...bill, ...billUpdate };
    this.billsStore.set(id, updatedBill);
    return updatedBill;
  }
  
  async markBillAsPaid(id: number, isPaid: boolean): Promise<Bill | undefined> {
    const bill = this.billsStore.get(id);
    if (!bill) return undefined;
    
    bill.isPaid = isPaid;
    this.billsStore.set(id, bill);
    return bill;
  }
  
  async deleteBill(id: number): Promise<boolean> {
    return this.billsStore.delete(id);
  }

  // Initialize with sample data
  private initializeSampleData() {
    // Sample expenses
    const expenseSamples: InsertExpense[] = [
      {
        description: "Grocery Shopping",
        amount: 850000,
        category: "Food & Dining",
        date: new Date(),
        paymentMethod: "Cash",
        notes: "Weekly grocery shopping"
      },
      {
        description: "Gas",
        amount: 200000,
        category: "Transportation",
        date: new Date(Date.now() - 24 * 60 * 60 * 1000), // yesterday
        paymentMethod: "Debit Card",
        notes: "Filled up the tank"
      },
      {
        description: "Lunch",
        amount: 125000,
        category: "Food & Dining",
        date: new Date(Date.now() - 24 * 60 * 60 * 1000), // yesterday
        paymentMethod: "Cash"
      },
      {
        description: "Movie Tickets",
        amount: 150000,
        category: "Entertainment",
        date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        paymentMethod: "Credit Card"
      },
      {
        description: "Internet Bill",
        amount: 350000,
        category: "Utilities",
        date: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
        paymentMethod: "Bank Transfer",
        notes: "Monthly internet subscription"
      }
    ];

    // Sample budgets
    const budgetSamples: InsertBudget[] = [
      {
        name: "Daily Necessities",
        category: "Food & Dining",
        amount: 3500000,
        period: "Monthly",
        startDate: new Date(),
        alertPercentage: 80
      },
      {
        name: "Food & Dining",
        category: "Food & Dining",
        amount: 1500000,
        period: "Monthly",
        startDate: new Date(),
        alertPercentage: 80
      },
      {
        name: "Transportation",
        category: "Transportation",
        amount: 1200000,
        period: "Monthly",
        startDate: new Date(),
        alertPercentage: 75
      }
    ];

    // Sample bills
    const billSamples: InsertBill[] = [
      {
        name: "Internet & TV",
        amount: 500000,
        category: "Internet",
        dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000), // 2 days from now
        recurrence: "Monthly",
        reminderDays: 3,
        notes: "IndiHome subscription",
        isPaid: false
      },
      {
        name: "Electricity",
        amount: 750000,
        category: "Electricity",
        dueDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), // 5 days from now
        recurrence: "Monthly",
        reminderDays: 5,
        notes: "PLN bill",
        isPaid: false
      },
      {
        name: "Credit Card",
        amount: 1200000,
        category: "Other",
        dueDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000), // 10 days from now
        recurrence: "Monthly",
        reminderDays: 7,
        notes: "BCA credit card",
        isPaid: false
      }
    ];

    // Add sample data to storage
    expenseSamples.forEach(expense => {
      const id = this.expenseId++;
      this.expensesStore.set(id, { ...expense, id });
    });

    budgetSamples.forEach(budget => {
      const id = this.budgetId++;
      
      // Calculate current spending for this category
      const currentSpent = Array.from(this.expensesStore.values())
        .filter(expense => expense.category === budget.category)
        .reduce((sum, expense) => sum + expense.amount, 0);
      
      this.budgetsStore.set(id, { ...budget, id, currentSpent });
    });

    billSamples.forEach(bill => {
      const id = this.billId++;
      this.billsStore.set(id, { ...bill, id });
    });
  }
}

export const storage = new MemStorage();
